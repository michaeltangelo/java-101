public class Exercise3 {

	public static void main(String[] args) {
		//9.5 x 4.5 - 2.5 x 3 / 45.5 - 3.5

		double numerator = (9.5*4.5)-(2.5*3);
		double denominator = 45.5-3.5;
		double quotient = numerator/denominator;

		System.out.println(quotient);
	}
}